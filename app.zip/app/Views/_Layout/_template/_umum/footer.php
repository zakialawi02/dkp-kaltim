   <!-- ======= Footer ======= -->
   <!-- CPR -->
   <div class="container-fluid footer pt-5 wow fadeIn">
       <div class="container-fluid copyright">
           <div class="container">
               <div class="row">
                   <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                       &copy; <a href="<?= base_url(); ?>">
                       </a>All Right Reserved.
                   </div>
                   <div class="col-md-6 text-center text-md-end">
                       <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                       <!-- Designed By <a href="https://htmlcodex.com">HTML Codex</a> Distributed By <a href="https://themewagon.com">ThemeWagon</a> -->
                   </div>
               </div>
           </div>
       </div>
   </div>
   <!-- CPR End -->

   <!-- Back to TOP -->
   <a href="#" class="scroll-top">
       <i class="bi bi-arrow-up-short"></i>
   </a>