<header>
    <div class="logo"><a href="/"><img class="img-fluid navbar-logo me-2" src="/img/logo navbar.png" alt="DINAS KELAUTAN DAN PERIKANAN PROVINSI KALIMANTAN TIMUR" style="max-width: 12rem;"></a>
    </div>
    <nav>
        <ul>
            <li><a href="/" class="nav-link bi bi-house-door-fill">Beranda</a></li>
        </ul>
    </nav>
    <div class="menu-toggle">
        <i class="bi bi-list"></i>
    </div>
</header>